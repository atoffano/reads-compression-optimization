# reads-compression-optimization
Optimizing biological sequencing data organization for a better compression efficiency.

## Todo
Côté architecture du code
- fonction pour la visualisation (graph)
- Eventuellement un fichier de logs des tests (type .csv) prenant l'output du logger

Stratégies
- Fonction baseline de sorting (à trouver) pour comparer le reste
- Fonctions à tester
